<?php
$conexion = new mysqli("localhost", "root", "", "tianguis_store");
if ($conexion->connect_error) {
  die("Conexión fallida: " . $conexion->connect_error);
}
?>