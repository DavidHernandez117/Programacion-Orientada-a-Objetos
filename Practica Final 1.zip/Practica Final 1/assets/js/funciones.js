fetch('productos.php')
  .then(res => res.json())
  .then(data => {
    const contenedor = document.getElementById('productos');
    data.forEach(prod => {
      const div = document.createElement('div');
      div.className = 'producto';
      div.innerHTML = `
        <img src="${prod.imagen}" alt="${prod.nombre}">
        <h3>${prod.nombre}</h3>
        <p>$${prod.precio}</p>
        <button>Comprar</button>
      `;
      contenedor.appendChild(div);
    });
  });