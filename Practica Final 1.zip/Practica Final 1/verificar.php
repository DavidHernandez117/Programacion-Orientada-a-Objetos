<?php
session_start();
include("db/conexion.php");

$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND contrasena = '$contrasena'";
$resultado = mysqli_query($conexion, $sql);

if (mysqli_num_rows($resultado) > 0) {
  $_SESSION['usuario'] = $usuario;
  header("Location: index.php");
} else {
  echo "Error: Usuario o contraseña incorrectos.";
}
?>