<?php
session_start();
if (!isset($_SESSION['usuario'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tianguis Store</title>
  <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body>
  <h1>Bienvenido, <?php echo $_SESSION['usuario']; ?> <a href="logout.php">Cerrar sesión</a></h1>
  <div class="productos" id="productos"></div>
  <script src="assets/js/funciones.js"></script>
</body>
</html>